package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver = null;
	@Given("^The User is on Demoweb shop Home page$")
	public void the_User_is_on_Demoweb_shop_Home_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com/");
		driver.manage().window().maximize(); 	   
	}

	@When("^User clicks on Registerlink$")
	public void user_clicks_on_Registerlink() throws Throwable {
		driver.findElement(By.linkText("Register")).click();
	}


	@When("^Enters the First name (.+)$")
	public void enter_first_name(String fn) throws Throwable {
		driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys(fn);
	}

	@When("^Enters the Second name (.+)$")
	public void second_name(String ln) throws Throwable {
		driver.findElement(By.xpath("//input[@id='LastName']")).sendKeys(ln);
	}

	@When("^Enters Email (.+)$")
	public void email(String em) throws Throwable {
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys(em);
	}

	@When("^Password$")
	public void password() throws Throwable {
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("pass123");  
	}

	@When("^Confim Password$")
	public void confim_Password() throws Throwable {
		driver.findElement(By.id("ConfirmPassword")).sendKeys("pass123");

	}

	@When("^Click Register button$")
	public void click_Register_button() throws Throwable {
		driver.findElement(By.id("register-button")).click();
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@class='ico-logout']"));

	}

	/*@Then("^The Application terminates$")
	public void The_Application_terminates() throws Throwable {
		driver.close();
	}*/

	@Then("^Browser is closed$")
	public void browser_is_closed() throws Throwable {
		driver.close();
	 	}
	
	@Given("^This is a blank test$")
	public void this_is_a_blank_test() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 
	}
}
