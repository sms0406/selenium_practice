package StepDefinitions;

import ElementLocators.ElementLocators_DemoQA;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
		
	@Given("^I want to open website newtours$")
	public void i_want_to_open_website_newtours() throws Throwable {
		System.out.println("new");	    
	PageFactPack.PageFactory.openbrowser("http://newtours.demoaut.com");
	}
	
		
	@When("^I click on register link it should open the register page$")
		public void i_click_on_register_link_it_should_open_the_register_page() throws Throwable {	
		System.out.println("new");
		PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.LinkText);
	}
		
	@Then("^I want to send firstname$")
	public void i_want_to_send_firstname() throws Throwable {
		PageFactPack.PageFactory.SendValue("Muthu",ElementLocators_DemoQA.FirstName);
	}

	@And("^I want to send lastname$")
	public void i_want_to_send_lastname() throws Throwable {
		PageFactPack.PageFactory.SendValue("raman",ElementLocators_DemoQA.LastName);
	}

	@And("^I want to send phone number$")
	public void i_want_to_send_phone_number() throws Throwable {
		PageFactPack.PageFactory.SendValue("9444280084",ElementLocators_DemoQA.phone);
	}

	@And("^I want to send email$")
	public void i_want_to_send_email() throws Throwable {
		PageFactPack.PageFactory.SendValue("ruchi@gmail.com",ElementLocators_DemoQA.email);
	}

	@And("^I want to send Address$")
	public void i_want_to_send_Address() throws Throwable {
		PageFactPack.PageFactory.SendValue("7-6-284/c,mittastreet",ElementLocators_DemoQA.address);
	}

	@And("^I want to send City name$")
	public void i_want_to_send_City_name() throws Throwable {
		PageFactPack.PageFactory.SendValue("chennai",ElementLocators_DemoQA.city);
	}

	@And("^I want to send State$")
	public void i_want_to_send_State() throws Throwable {
		PageFactPack.PageFactory.SendValue("TN",ElementLocators_DemoQA.state);
	}

	@And("^I want to send Postalcode$")
	public void i_want_to_send_Postalcode() throws Throwable {
		PageFactPack.PageFactory.SendValue("600032",ElementLocators_DemoQA.postalcode);
	}
	
	@And("^I want to select country$")
	public void i_want_to_select_country() throws Throwable {
		PageFactPack.PageFactory.select(ElementLocators_DemoQA.country,"INDIA");
	}
	@And("^I want to enter user name$")
	public void i_want_to_enter_user_name() throws Throwable {
		PageFactPack.PageFactory.SendValue("sanam",ElementLocators_DemoQA.username);
	}

	@And("^I want to enter password$")
	public void i_want_to_enter_password() throws Throwable {
		PageFactPack.PageFactory.SendValue("kamesh",ElementLocators_DemoQA.password);
	}

	@And("^I want to confirm password$")
	public void i_want_to_confirm_password() throws Throwable {
		PageFactPack.PageFactory.SendValue("kamesh",ElementLocators_DemoQA.confirmpassword);
	}

	@Then("^I click on submit button$")
	public void i_click_on_submit_button() throws Throwable {
		PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.submit);
	}
	
   @Then("^click on signoff link it should open sign on page$")
   public void click_on_signoff_link_it_should_open_sign_on_page() throws Throwable {
	   PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.linkText);   	
    }
   
   @Then("^I click on hotels link then it should open hotel page$")
   public void i_click_on_hotels_link_then_it_should_open_hotel_page() throws Throwable {
	   PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.hotel);   	
    }
     	
   @Then("^I click on back to home button it will redirect to homepage$")
   public void i_click_on_Back_to_home_button_it_will_redirect_to_homepage() throws Throwable {
	   PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.back);   	
    }
   @Then("^I terminate the application$")
   public void i_terminate_the_application() throws Throwable{
	   PageFactPack.PageFactory.close();
   }
   
	@Given("^the user is on the Demowebshop Home page$")
	public void the_user_is_on_the_Demowebshop_Home_page() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   PageFactPack.PageFactory.openbrowser("http://demowebshop.tricentis.com");	
   }
	
	@When("^he clicks on Registerlink$")
	public void he_clicks_on_Registerlink() throws Throwable {
		 PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.Reglink);
	
	}

	@When("^enters First name$")
	public void enters_First_name() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   PageFactPack.PageFactory.SendValue("Muthu",ElementLocators_DemoQA.Firstname);
   }

	@When("^enters Second name$")
	public void enters_Second_name() throws Throwable {
	   PageFactPack.PageFactory.SendValue("Raman",ElementLocators_DemoQA.Lastname);
      
   }

	@When("^enters Email$")
	public void enters_Email() throws Throwable {
       PageFactPack.PageFactory.SendValue("smuthuram14@gmail.com",ElementLocators_DemoQA.Email);
      
   }

	@When("^enters Password$")
	public void enters_Password() throws Throwable {
       // Write code here that turns the phrase above into concrete actions
	   PageFactPack.PageFactory.SendValue("mutc1234",ElementLocators_DemoQA.Password);
   }

	@When("^enters Confim Password$")
	public void enters_Confim_Password() throws Throwable {
	   PageFactPack.PageFactory.SendValue("mutc1234",ElementLocators_DemoQA.ConfirmPassword);
      
   }
	
	@When("^click on Register button$")
	public void click_on_Register_button() throws Throwable {
		 PageFactPack.PageFactory.clickmethod(ElementLocators_DemoQA.Registerbutton);
	
	}

	@Then("^the user is successfully registered$")
	public void the_user_is_successfully_registered() throws Throwable {
	 
     }

	@Then("^application terminates$")
	public void application_terminates() throws Throwable {
		PageFactPack.PageFactory.close();
	    
	}
	
	
		
}
