package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Invoke_Browser {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("http://demowebshop.tricentis.com");
		
		//ALERT HANDLING
		/*driver.navigate().to("C:/Users/msharm65/Desktop/drop.html");
		driver.findElement(By.xpath("//button[text()='Try it']")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		Thread.sleep(3000);
		driver.findElement(By.id("name")).sendKeys("HELLO WORLD");*/

		
		//Select Choosing
		/*driver.navigate().to("C:/Users/msharm65/Desktop/drop.html");
		WebElement element= driver.findElement(By.id("select"));
		Select select=new Select(element);
		select.selectByIndex(1);
		Thread.sleep(3000);
		select.selectByValue("mercedes");
		Thread.sleep(3000);
		select.selectByVisibleText("Audi");*/
		
		
	/*	Thread.sleep(3000);
		driver.findElement(By.className("ico-register")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("gender-male")).click();
		driver.findElement(By.id("FirstName")).sendKeys("Mayank");
		driver.findElement(By.id("LastName")).sendKeys("Sharma");
		driver.findElement(By.id("Email")).sendKeys("mayank12341@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("demodemo");
		driver.findElement(By.id("ConfirmPassword")).sendKeys("demodemo");
		driver.findElement(By.name("register-button")).click();
		Thread.sleep(3000);
		driver.findElement(By.className("ico-logout")).click();
		Thread.sleep(3000);*/
		/*driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("mayank12341@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("demodemo");
		driver.findElement(By.xpath("//input[@value='Log in']")).click();*/
		//driver.findElement(By.xpath("(//a[@href='/computers'])[3]")).click();
		//driver.findElement(By.xpath("//img[@alt='Picture for category Desktops']")).click();
		
		/*Select choice=new Select(driver.findElement(By.id("products-orderby")));
		choice.selectByIndex(3);
		System.out.println("BY INDEX");
		choice.selectByVisibleText("Created on");
		System.out.println("BY visible text");
		choice.selectByValue("http://demowebshop.tricentis.com/desktops?orderby=6");
		System.out.println("By Value");*/
		
		//driver.findElement(By.id("products-orderby"))
		
		/*
		driver.findElement(By.className("ico-register")).click();
		Thread.sleep(3000);
		WebElement element= driver.findElement(By.name("register-button"));
		element.click();
		WebElement element1=driver.findElement(By.xpath("//span[@data-valmsg-for='FirstName']"));
		System.out.println(element1.getText());*/
		
		driver.get("https://www.toolsqa.com/automation-practice-switch-windows/");
		System.out.println(driver.getWindowHandles());
		driver.findElement(By.id("cookie_action_close_header")).click();
		Thread.sleep(3000);
		WebElement element=driver.findElement(By.xpath("//button[text()='New Message Window']"));
		element.click();
		System.out.println(driver.getWindowHandle());
	}	

}
