package demo;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;
public class TestClass {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("C:/Users/msharm65/Desktop/Hotel booking case study/login.html");
		WebElement w1=driver.findElement(By.xpath("//h1[text()=' Hotel Booking Application ']"));

		Assert.assertEquals("Hotel Booking Application", w1.getText());
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		WebElement element=driver.findElement(By.id("userErrMsg"));
		Assert.assertEquals("* Please enter userName.", element.getText());
		
		
		/*String expected=" * Please enter userName.";
		WebElement element=driver.findElement(By.id("userErrMsg"));
		String actual = element.getText();*/
		
//		Assert.assertEquals(expected, actual);

		
	}
}
